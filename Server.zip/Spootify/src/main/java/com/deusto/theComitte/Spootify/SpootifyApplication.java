package com.deusto.theComitte.Spootify;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpootifyApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpootifyApplication.class, args);
	}

}
